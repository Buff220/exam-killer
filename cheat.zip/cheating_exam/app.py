import cv2
from flask import Flask, Response, render_template,jsonify
import pytesseract
import requests

CAM_URL = "rtsp://192.168.100.1:8080/?action=stream"
GROQ_API_KEY = open("api.txt").read().strip()
MODEL = "moonshotai/kimi-k2-instruct"

app = Flask(__name__)
cap = cv2.VideoCapture(CAM_URL)
paused = False
last_frame = None

def ask_groq(text):
    prompt = f"""
Extract the correct answers from this text.
Format only like:

1-a
2-c
3-d

Text:
{text}
"""

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0
    }

    r = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        json=data,
        headers=headers
    )

    return r.json()["choices"][0]["message"]["content"]

def gen_frames():
    global paused, last_frame

    while True:
        success, frame = cap.read()
        if not success:
            continue
        if not paused:
            last_frame = frame  # update last frame only if not paused
            disp_frame= frame 
        else:
            disp_frame=cv2.cvtColor(last_frame, cv2.COLOR_BGR2GRAY)
        #display gray frame
        ret, buffer = cv2.imencode('.jpg', disp_frame)
        frame_bytes = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

def ocr_text(frame):
    gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return pytesseract.image_to_string(gray)
ZeroDivisionError
@app.route('/pause', methods=['POST','GET'])
def pause():
    global paused
    paused = True
    return ('', 204)


@app.route('/resume', methods=['POST','GET'])
def resume():
    global paused
    paused = False
    return ('', 204)

@app.route('/process', methods=['POST','GET'])
def process():
    global last_frame
    if last_frame is None:
        return jsonify({"text": "No frame available"}), 400
    text = ocr_text(last_frame)
    ai= ask_groq(text)
    return jsonify({"text": text, "ai": ai})

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
