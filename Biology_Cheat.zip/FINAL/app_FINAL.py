import cv2
from flask import Flask, Response, render_template, jsonify
import requests, time, base64
from PIL import Image
import io,base64
from groq import Groq

CAM_URL = 0
GROQ_API_KEY = open("api.txt").read().strip()

app = Flask(__name__)
cap = cv2.VideoCapture(0)
paused = False
last_frame = None


def ask_groq_image(image, api_key=GROQ_API_KEY):
    """
    Extracts answers from an image using the Groq API with the specified model.
    
    :param image: NumPy array from cv2.imread (e.g., cv2.imread('image.png'))
    :param api_key: Your Groq API key as a string
    :return: The response content from the model
    """
    # Initialize the Groq client
    client = Groq(api_key=api_key)
    
    # Encode the image to base64
    success, encoded_image = cv2.imencode('.png', image)
    if not success:
        raise ValueError("Failed to encode the image to PNG format.")
    
    base64_image = base64.b64encode(encoded_image.tobytes()).decode('utf-8')
    
    # Prepare the messages for the API call
    messages = [
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "Extract the correct answers from this text.\nFormat only like:\n\n1-a\n2-c\n3-d\n\nText from image:"
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/png;base64,{base64_image}"
                    }
                }
            ]
        }
    ]
    
    # Make the API call
    response = client.chat.completions.create(
        model="meta-llama/llama-4-scout-17b-16e-instruct",
        messages=messages
    )
    
    # Return the response content
    return response.choices[0].message.content



def gen_frames():
    global paused, last_frame

    while True:
        success, frame = cap.read()
        if not success:
            time.sleep(0.01)
            continue

        if not paused:
            last_frame = frame
            disp_frame = frame
        else:
            disp_frame = last_frame

        ret, buffer = cv2.imencode(".jpg", disp_frame)
        frame_bytes = buffer.tobytes()

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
        )


@app.route('/pause', methods=['POST','GET'])
def pause():
    global paused
    paused = True
    return ('', 204)


@app.route('/resume', methods=['POST','GET'])
def resume():
    global paused
    paused = False
    return ('', 204)


@app.route('/process', methods=['POST','GET'])
def process():
    global last_frame
    if last_frame is None:
        return jsonify({"error": "No frame available"}), 400

    ai_output = ask_groq_image(last_frame)
    return jsonify({"ai": ai_output})


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/video_feed')
def video_feed():
    return Response(
        gen_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
